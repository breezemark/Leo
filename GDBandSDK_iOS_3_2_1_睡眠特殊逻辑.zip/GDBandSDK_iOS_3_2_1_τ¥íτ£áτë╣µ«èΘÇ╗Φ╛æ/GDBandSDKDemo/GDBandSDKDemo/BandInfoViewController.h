//
//  BandInfoViewController.h
//  GDBandSDK
//
//  Created by darren on 15/11/4.
//  Copyright © 2015年 gieseckedevrient. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BandInfoViewController : UITableViewController
@property (weak, nonatomic) IBOutlet UILabel *alertBeginLabel;
@property (weak, nonatomic) IBOutlet UILabel *alertEndLabel;
@property (weak, nonatomic) IBOutlet UILabel *alertIntervalLabel;
@property (weak, nonatomic) IBOutlet UILabel *alertDaySwitchLabel;
@property (weak, nonatomic) IBOutlet UILabel *alertEnableLabel;
@property (weak, nonatomic) IBOutlet UILabel *alarmHourLabel;
@property (weak, nonatomic) IBOutlet UILabel *alarmMinLabel;
@property (weak, nonatomic) IBOutlet UILabel *alarmDaySwitchLabel;
@property (weak, nonatomic) IBOutlet UILabel *alarmEnableLabel;
@property (weak, nonatomic) IBOutlet UILabel *batteryLabel;

@end
