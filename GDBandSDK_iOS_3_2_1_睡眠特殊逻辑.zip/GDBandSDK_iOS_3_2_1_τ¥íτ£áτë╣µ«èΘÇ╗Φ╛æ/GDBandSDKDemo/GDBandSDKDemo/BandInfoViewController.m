//
//  BandInfoViewController.m
//  GDBandSDK
//
//  Created by darren on 15/11/4.
//  Copyright © 2015年 gieseckedevrient. All rights reserved.
//

#import "BandInfoViewController.h"
#import "GDBandSDK.h"

@interface BandInfoViewController ()
{
    GDBandInfo *_bandInfo;
}
@end

@implementation BandInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.section) {
        case 0:
        {
            if (!_bandInfo) {
                [self showAlertText:@"请先读取设置"];
                break;
            }
            switch (indexPath.row) {
                case 0:
                {
                    [self showInputAlertWithText:@"请输入活动提醒开始时间：（单位:时 例:9）" tag:101];
                }
                    break;
                    
                case 1:
                {
                    [self showInputAlertWithText:@"请输入活动提醒结束时间：（单位:时 例:20）" tag:102];
                }
                    break;
                    
                case 2:
                {
                    [self showInputAlertWithText:@"请输入活动提醒时间间隔：（单位:分钟 例:40 必须为10的倍数）" tag:103];
                }
                    break;
                    
                case 3:
                {
                    [self showInputAlertWithText:@"活动提醒各天开关\n一二三四五六日\n例:1111100）" tag:106];
                }
                    break;
                    
                case 4:
                {
                    [self showOnOffAlertWithText:@"活动提醒总开关" tag:201];
                }
                    break;
                    
                case 5:
                {
                    [self showInputAlertWithText:@"请输入闹钟 时：（单位:时 例:9）" tag:104];
                }
                    break;
                    
                case 7:
                {
                    [self showInputAlertWithText:@"闹钟各天开关\n一二三四五六日\n例:1111100）" tag:107];
                }
                    break;
                    
                case 6:
                {
                    [self showInputAlertWithText:@"请输入闹钟 分：（单位:分 例:30）" tag:105];
                }
                    break;
                    
                case 8:
                {
                    [self showOnOffAlertWithText:@"闹钟总开关" tag:202];
                }
                    break;
                    
                default:
                    break;
            }
        }
            break;
            
        case 1:
        {
            switch (indexPath.row) {
                case 0:
                {
                    
                    BOOL success = [[GDBandManager sharedManager] getBandInfo:^(BOOL success, GDBandInfo *bandInfo) {
                        if (success) {
                            _bandInfo = bandInfo;
                            [self refreshDisplay];
                        }
                        else {
                            [self showAlertText:@"通讯失败"];
                        }
                    }];
                    if (!success) {
                        [self showAlertText:@"手环未连接"];
                    }
                }
                    break;
                    
                case 1:
                {
                    if (!_bandInfo) {
                        [self showAlertText:@"请先读取设置"];
                        break;
                    }
                    BOOL success = [[GDBandManager sharedManager] updateBandInfo:_bandInfo completion:^(BOOL success) {
                        [self showAlertText:success ? @"设置成功" : @"设置失败"];
                    }];
                    if (!success) {
                        [self showAlertText:@"手环未连接"];
                    }
                }
                    break;
                    
                default:
                    break;
            }
        }
            break;
            
        default:
            break;
    }
}

- (void)showInputAlertWithText:(NSString *)text tag:(NSInteger)tag
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:text delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [alertView setAlertViewStyle:UIAlertViewStylePlainTextInput];
    [[alertView textFieldAtIndex:0] setKeyboardType:UIKeyboardTypeNumberPad];
    alertView.tag = tag;
    [alertView show];
}

- (void)showOnOffAlertWithText:(NSString *)text tag:(NSInteger)tag
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:text delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"开启", @"关闭", nil];
    alertView.tag = tag;
    [alertView show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag > 200) {
        switch (alertView.tag) {
            case 201:
            {
                if (buttonIndex == 1) {
                    _bandInfo.alertEnable = YES;
                    [self refreshDisplay];
                }
                else if (buttonIndex == 2) {
                    _bandInfo.alertEnable = NO;
                    [self refreshDisplay];
                }
            }
                break;
                
            case 202:
            {
                if (buttonIndex == 1) {
                    _bandInfo.alarmEnable = YES;
                    [self refreshDisplay];
                }
                else if (buttonIndex == 2) {
                    _bandInfo.alarmEnable = NO;
                    [self refreshDisplay];
                }
            }
                break;
                
            default:
                break;
        }
        return;
    }
    if (buttonIndex == 1) {
        UITextField *tf = [alertView textFieldAtIndex:0];
        switch (alertView.tag) {
            case 101:
            {
                _bandInfo.alertBeginHour = tf.text.intValue;
                [self refreshDisplay];
            }
                break;
                
            case 102:
            {
                _bandInfo.alertEndHour = tf.text.intValue;
                [self refreshDisplay];
            }
                break;
                
            case 103:
            {
                _bandInfo.alertInterval = tf.text.intValue;
                [self refreshDisplay];
            }
                break;
                
            case 104:
            {
                _bandInfo.alarmHour = tf.text.intValue;
                [self refreshDisplay];
            }
                break;
                
            case 105:
            {
                _bandInfo.alarmMin = tf.text.intValue;
                [self refreshDisplay];
            }
                break;
                
            case 106:
            {
                _bandInfo.alertDayFlag = [self flagWithStr:tf.text];
                [self refreshDisplay];
            }
                break;
                
            case 107:
            {
                _bandInfo.alarmDayFlag = [self flagWithStr:tf.text];
                [self refreshDisplay];
            }
                break;
                
            default:
                break;
        }
    }
}

- (void)refreshDisplay
{
    _alertBeginLabel.text = [NSString stringWithFormat:@"%02d:00", _bandInfo.alertBeginHour];
    _alertEndLabel.text = [NSString stringWithFormat:@"%02d:00", _bandInfo.alertEndHour];
    _alertIntervalLabel.text = [NSString stringWithFormat:@"%d 分钟", _bandInfo.alertInterval];
    _alarmHourLabel.text = [NSString stringWithFormat:@"%02d 时", _bandInfo.alarmHour];
    _alarmMinLabel.text = [NSString stringWithFormat:@"%d 分", _bandInfo.alarmMin];
    _batteryLabel.text = [NSString stringWithFormat:@"%d%%", _bandInfo.battery];
    _alertDaySwitchLabel.text = [self dayStringWithDayFlag:_bandInfo.alertDayFlag];
    _alarmDaySwitchLabel.text = [self dayStringWithDayFlag:_bandInfo.alarmDayFlag];
    _alertEnableLabel.text = _bandInfo.alertEnable ? @"已开启" : @"已关闭";
    _alarmEnableLabel.text = _bandInfo.alarmEnable ? @"已开启" : @"已关闭";
}

- (int)flagWithStr:(NSString *)str
{
    if (str.length < 7) {
        return 0;
    }
    int flag = 0;
    for (int i = 0; i < 7; i++) {
        int number = [[str substringWithRange:NSMakeRange(i, 1)] intValue];
        switch (i) {
            case 0:
                if (number) {
                    flag |= GDDayMon;
                }
                break;
                
            case 1:
                if (number) {
                    flag |= GDDayTues;
                }
                break;
                
            case 2:
                if (number) {
                    flag |= GDDayWed;
                }
                break;
                
            case 3:
                if (number) {
                    flag |= GDDayThur;
                }
                break;
                
            case 4:
                if (number) {
                    flag |= GDDayFri;
                }
                break;
                
            case 5:
                if (number) {
                    flag |= GDDaySat;
                }
                break;
                
            case 6:
                if (number) {
                    flag |= GDDaySun;
                }
                break;
                
            default:
                break;
        }
    }
    return flag;
}

- (NSString *)dayStringWithDayFlag:(int)flag
{
    NSMutableString *str = [NSMutableString string];
    if (flag & GDDayMon) {
        [str appendString:@"一,"];
    }
    if (flag & GDDayTues) {
        [str appendString:@"二,"];
    }
    if (flag & GDDayWed) {
        [str appendString:@"三,"];
    }
    if (flag & GDDayThur) {
        [str appendString:@"四,"];
    }
    if (flag & GDDayFri) {
        [str appendString:@"五,"];
    }
    if (flag & GDDaySat) {
        [str appendString:@"六,"];
    }
    if (flag & GDDaySun) {
        [str appendString:@"日"];
    }
    if (str.length) {
        if ([[str substringFromIndex:str.length - 1] isEqualToString:@","]) {
            str = [NSMutableString stringWithString:[str substringToIndex:str.length - 1]];
        }
    }
    else {
        [str appendString:@"无"];
    }
    return str;
}

- (void)showAlertText:(NSString *)text
{
    [[[UIAlertView alloc] initWithTitle:@"提示" message:text delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil] show];
}

@end
