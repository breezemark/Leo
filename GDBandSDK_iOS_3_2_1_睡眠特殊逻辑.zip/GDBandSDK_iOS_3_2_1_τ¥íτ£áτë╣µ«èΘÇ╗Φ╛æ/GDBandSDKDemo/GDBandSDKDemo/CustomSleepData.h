//
//  CustomSleepData.h
//  GDBandSDKDemo
//
//  Created by LiZengshun on 2017/8/21.
//  Copyright © 2017年 gieseckedevrient. All rights reserved.
//

#import <Foundation/Foundation.h>

@class GDSleepDetail;
@interface CustomSleepData : NSObject
@property (nonatomic, assign) NSTimeInterval gotoSleepPoint;
@property (nonatomic, assign) NSTimeInterval getUpPoint;
@property (nonatomic, assign) NSTimeInterval lightSleepTime;
@property (nonatomic, assign) NSTimeInterval deepSleepTime;
@property (nonatomic, assign) NSTimeInterval wakeupTime;
@property (nonatomic, strong) NSMutableArray<GDSleepDetail *> *detailArray;
@end
