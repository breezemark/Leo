//
//  CustomSleepData.m
//  GDBandSDKDemo
//
//  Created by LiZengshun on 2017/8/21.
//  Copyright © 2017年 gieseckedevrient. All rights reserved.
//

#import "CustomSleepData.h"

@implementation CustomSleepData

@end
