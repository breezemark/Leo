//
//  DeviceViewController.h
//  GDBandSDKDemo
//
//  Created by darren on 15/10/25.
//  Copyright © 2015年 gieseckedevrient. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GDBandSDK.h"

@interface DeviceViewController : UITableViewController

@property (weak, nonatomic) IBOutlet UILabel *stateLabel;
@property (weak, nonatomic) IBOutlet UILabel *realTimeStepLabel;
@property (nonatomic, strong) CBPeripheral *selectedDevice;
@end
