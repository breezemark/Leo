//
//  DeviceViewController.m
//  GDBandSDKDemo
//
//  Created by darren on 15/10/25.
//  Copyright © 2015年 gieseckedevrient. All rights reserved.
//

#import "DeviceViewController.h"
#import "CustomSleepData.h"

@interface DeviceViewController ()<GDBandManagerDelegate,GDBandManagerAPDUDelegate,GDBandDFUDelegate>
{
    GDBandManager *_bandManager;
    UIAlertController *_dfuAlertController;
}
@end

@implementation DeviceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _bandManager = [GDBandManager sharedManager];
    [_bandManager stopDiscoverDevice];
    [_bandManager setDelegate:self];
    [_bandManager setApduDelegate:self];
    _stateLabel.text = @"未连接";
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    if (![self.navigationController.viewControllers containsObject:self]) {
        [_bandManager disconnectDevice];
    }
}

#pragma mark - Table view data source
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.section) {
        case 1:
        {
            switch (indexPath.row) {
                case 0:
                {
                    // 连接设备（新绑定）
                    if (_bandManager.state == GDBandManagerStateDisconnected) {
                        [_bandManager connectDevice:_selectedDevice isFirst:YES];
                        [self showStateText:@"正在连接..."];
                    }
                }
                    break;
                    
                case 1:
                {
                    // 连接设备（已绑定设备）
                    if (_bandManager.state == GDBandManagerStateDisconnected) {
                        [_bandManager connectDevice:_selectedDevice isFirst:NO];
                        [self showStateText:@"正在连接..."];
                    }
                }
                    break;
                    
                case 2:
                {
                    // 断开设备
                    if (_bandManager.state == GDBandManagerStateConnected) {
                        [_bandManager disconnectDevice];
                        [self showStateText:@"正在断开..."];
                    }
                }
                    break;
                    
                default:
                    break;
            }
        }
            break;
            
        case 2:
        {
            if (_bandManager.state != GDBandManagerStateConnected) {
                [self alertWithTitle:@"提示" message:@"请先连接手环"];
                return;
            }
            switch (indexPath.row) {
                case 0:
                {
                    // 读取设备类型和固件版本
                    [_bandManager getDeviceTypeAndVersion:^(BOOL success, int type, int versionMajor, int versionMinor) {
                        if (success) {
                            [self alertWithTitle:@"提示" message:[NSString stringWithFormat:@"设备类型：%d\n固件版本%d.%d", type, versionMajor, versionMinor]];
                        }
                        else {
                            [self alertWithTitle:@"错误" message:@"读取失败"];
                        }
                    }];
                }
                    break;
                    
                case 1:
                {
                    // 更新时间
                    [_bandManager updateDeviceTime:^(BOOL success) {
                        if (success) {
                            [self alertWithTitle:@"提示" message:@"更新成功"];
                        }
                        else {
                            [self alertWithTitle:@"错误" message:@"更新失败"];
                        }
                    }];
                }
                    break;
                    
                case 2:
                {
                    // 读取用户信息
                    [self performSegueWithIdentifier:@"UserInfo" sender:nil];
                }
                    break;
                    
                case 3:
                {
                    // 读取手环设置
                    [self performSegueWithIdentifier:@"BandInfo" sender:nil];
                }
                    break;
                    
                case 4:
                {
                    // 读取ANCS设置
                    [_bandManager getBandANCSStatus:^(BOOL success, GDBandANCSStatus status) {
                        if (success) {
                            [self alertWithTitle:@"提示" message:[NSString stringWithFormat:@"当前ANCS状态为：\n\n%@",
                                                                [self stringWithANCSStatus:status]]];
                        }
                        else {
                            [self alertWithTitle:@"错误" message:@"读取失败"];
                        }
                    }];
                }
                    break;
                    
                case 5:
                {
                    // 修改ANCS设置
                    void (^setANCSBlock)(GDBandANCSStatus status) = ^(GDBandANCSStatus status) {
                        [_bandManager updateBandANCSStatus:status completion:^(BOOL success) {
                            if (success) {
                                [self alertWithTitle:@"提示" message:@"更新成功"];
                            }
                            else {
                                [self alertWithTitle:@"错误" message:@"更新失败"];
                            }
                        }];
                    };
                    
                    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:@"请设置ANCS状态" preferredStyle:UIAlertControllerStyleAlert];
                    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
                    [alertController addAction:cancelAction];
                    [alertController addAction:[UIAlertAction actionWithTitle:[self stringWithANCSStatus:GDBandANCSStatusOFF]
                                                                        style:UIAlertActionStyleDefault
                                                                      handler:^(UIAlertAction * _Nonnull action) {
                                                                          setANCSBlock(GDBandANCSStatusOFF);
                                                                      }]];
                    [alertController addAction:[UIAlertAction actionWithTitle:[self stringWithANCSStatus:GDBandANCSStatusAllOn]
                                                                        style:UIAlertActionStyleDefault
                                                                      handler:^(UIAlertAction * _Nonnull action) {
                                                                          setANCSBlock(GDBandANCSStatusAllOn);
                                                                      }]];
                    [alertController addAction:[UIAlertAction actionWithTitle:[self stringWithANCSStatus:GDBandANCSStatusCallON]
                                                                        style:UIAlertActionStyleDefault
                                                                      handler:^(UIAlertAction * _Nonnull action) {
                                                                          setANCSBlock(GDBandANCSStatusCallON);
                                                                      }]];
                    [alertController addAction:[UIAlertAction actionWithTitle:[self stringWithANCSStatus:GDBandANCSStatusMessageON]
                                                                        style:UIAlertActionStyleDefault
                                                                      handler:^(UIAlertAction * _Nonnull action) {
                                                                          setANCSBlock(GDBandANCSStatusMessageON);
                                                                      }]];
                    [self presentViewController:alertController animated:YES completion:nil];
                }
                    break;
                    
                case 6:
                {
                    // 实时步数，卡路里
                    if (_bandManager.state != GDBandManagerStateConnected) {
                        [self alertWithTitle:@"提示" message:@"请先连接手环"];
                        return;
                    }
                    [_bandManager getRealTimeStepCalorieDistance:^(BOOL success, int step, float calorie, float distance) {
                        if (success) {
                            _realTimeStepLabel.text = [NSString stringWithFormat:@"%d步,%.0f大卡,%.0f米", step, calorie, distance];
                        }
                        else {
                            _realTimeStepLabel.text = @"读取失败";
                        }
                    }];
                    
                }
                    break;
                    
                case 7:
                {
                    // 读取运动数据
                    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:@"正在读取..." preferredStyle:UIAlertControllerStyleAlert];
                    [self presentViewController:alertController animated:YES completion:nil];
                    [_bandManager getSportAndSleepResult:^(BOOL success, NSArray *sportDataAry, GDSleepDay *sleepDay) {
                        [alertController dismissViewControllerAnimated:YES completion:^{
                            if (success) {
                                int totalStep = 0;
                                double totalCalorie = 0;
                                double totalDistance = 0;
                                for (GDSportData *data in sportDataAry) {
                                    totalStep += data.step;
                                    totalCalorie += data.calorie;
                                    totalDistance += data.distance;
                                }
                                NSString *sleepString = @"无睡眠";
                                if (sleepDay) {
                                    NSLog(@"----------- 修正前");
                                    [self logSleepData:sleepDay];
                                    CustomSleepData *sleepData = [self processSleepData:sleepDay];
                                    NSLog(@"----------- 修正后");
                                    [self logSleepData:sleepData];
                                    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                                    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                                    sleepString = [NSString stringWithFormat:@"入睡：%@\n起床：%@\n浅睡：%d分钟\n深睡：%d分钟\n起夜：%d分钟",
                                                   [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:sleepData.gotoSleepPoint]],
                                                   [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:sleepData.getUpPoint]],
                                                   (int)(sleepData.lightSleepTime / 60),
                                                   (int)(sleepData.deepSleepTime / 60),
                                                   (int)(sleepData.wakeupTime / 60)];
                                }
                                
                                [self alertWithTitle:@"提示" message:[NSString stringWithFormat:@"运动数据%d条\n\n总步数：%d\n总消耗：%.2f卡\n总距离：%.2f米\n\n睡眠数据：\n%@",
                                                                    (int)sportDataAry.count,
                                                                    totalStep,
                                                                    totalCalorie,
                                                                    totalDistance,
                                                                    sleepString]];
                            }
                            else {
                                [self alertWithTitle:@"错误" message:@"读取失败"];
                            }
                        }];
                        
                    }];
                }
                    break;
                    
                case 8:
                {
                    // 擦除运动数据
                    [_bandManager clearSportAndSleepData:^(BOOL success) {
                        if (success) {
                            [self alertWithTitle:@"提示" message:@"擦除成功"];
                        }
                        else {
                            [self alertWithTitle:@"错误" message:@"擦除失败"];
                        }
                    }];
                }
                    break;
                    
                case 9:
                {
                    // 查询微信运动注册状态
                    [_bandManager queryWechatSportStatus:^(BOOL success, BOOL isOpen) {
                        if (success) {
                            [self alertWithTitle:@"提示" message:[NSString stringWithFormat:@"查询成功\n微信运动：%@", isOpen ? @"已注册" : @"未注册"]];
                        }
                        else {
                            [self alertWithTitle:@"错误" message:@"查询失败"];
                        }
                    }];
                }
                    break;
                    
                case 10:
                {
                    // 注册微信运动
                    [_bandManager registerWechatSport:^(BOOL success) {
                        [self alertWithTitle:@"错误" message:success ? @"注册成功" : @"注册失败"];
                    }];
                }
                    break;
                    
                default:
                    break;
            }
        }
            break;
            
        case 3:
        {
            if (_bandManager.state != GDBandManagerStateConnected) {
                [self alertWithTitle:@"提示" message:@"请先连接手环"];
                return;
            }
            switch (indexPath.row) {
                case 0:
                {
                    // SE上电
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                        uint8_t atr[30];
                        uint8_t length;
                        BOOL success = [_bandManager SEChipOffOn:YES ATR:atr length:&length timeout:3000];
                        NSLog(@"ATR %d", length);
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [self alertWithTitle:@"提示" message:success ? @"上电成功！" : @"上电失败！"];
                        });
                    });
                }
                    break;
                    
                case 1:
                {
                    // SE下电
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                        BOOL success = [_bandManager SEChipOffOn:NO ATR:nil length:nil timeout:3000];
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [self alertWithTitle:@"提示" message:success ? @"下电成功！" : @"下电失败！"];
                        });
                    });
                }
                    break;
                    
                case 2:
                {
                    // 读BTC info
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                        NSData *data = [_bandManager getBTCInfoWithTimeout:3000];
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [self alertWithTitle:@"提示" message:[NSString stringWithFormat:@"BTC Info\n%@", data]];
                        });
                    });
                }
                    break;
                    
                case 3:
                {
                    // APDU测试
//                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
//                        [self apduTest1];
//                        [self apduTest2];
//                    });
                    
                    // 异步APUD指令
                    Byte bytes[] = {0x00, 0xa4, 0x00, 0x00, 0x02, 0x10, 0x01};
                    NSData *sendData = [NSData dataWithBytes:bytes length:7];
                    NSLog(@"send apdu data %@", sendData);
                    [_bandManager asyncSendAPDUData:sendData];
                }
                    break;
                    
                default:
                    break;
            }
        }
            break;
            
        case 4:
        {
            if (_bandManager.state != GDBandManagerStateConnected) {
                [self alertWithTitle:@"提示" message:@"请先连接手环"];
                return;
            }
            switch (indexPath.row) {
                case 0:
                {
                    // 检查固件版本
                    BOOL start = [_bandManager checkBandFirmwareVersion:^(NSDictionary *response) {
                        NSLog(@"response %@", response);
                        NSInteger result = [response[GDResponseResultName] integerValue];
                        if (result == GDSucceed) {
                            NSMutableString *text = [NSMutableString string];
                            BOOL needUpdate = [response[GDResponseNeedUpdateName] boolValue];
                            [text appendFormat:@"当前版本：%d.%d\n", [response[GDResponseMajorVersionName] intValue], [response[GDResponseMinorVersionName] intValue]];
                            [text appendFormat:@"是否需要升级：%@\n", needUpdate ? @"需要" : @"不需要"];
                            if (needUpdate) {
                                [text appendFormat:@"最新版本：%d.%d\n", [response[GDResponseLatestMajorVersionName] intValue], [response[GDResponseLatestMinorVersionName] intValue]];
                                NSArray *propertyName = @[@"可选升级", @"必须升级"];
                                [text appendFormat:@"版本特性：%@", propertyName[[response[GDResponseLatestVersionProperty] integerValue]]];
                            }
                            [self alertWithTitle:@"提示" message:text];
                        }
                        else {
                            NSString *text = [NSString stringWithFormat:@"请求失败，错误码：%ld", result];
                            [self alertWithTitle:@"提示" message:text];
                        }
                    }];
                    if (!start) {
                        [self alertWithTitle:@"提示" message:@"检查失败"];
                    }
                }
                    break;
                    
                case 1:
                {
                    // 升级固件
                    _dfuAlertController = [UIAlertController alertControllerWithTitle:@"固件升级"
                                                                              message:@"请稍后..."
                                                                       preferredStyle:UIAlertControllerStyleAlert];
                    [self presentViewController:_dfuAlertController animated:YES completion:^{
                        dispatch_async(dispatch_get_main_queue(), ^{
                            BOOL start = [_bandManager startDFUWithDelegate:self];
                            if (!start) {
                                [_dfuAlertController dismissViewControllerAnimated:YES completion:^{
                                    [self alertWithTitle:@"提示" message:@"请先检查最新版本"];
                                }];
                            }
                        });
                    }];
                }
                    break;
                    
                default:
                    break;
            }
        }
            break;
        default:
            break;
    }
}

#pragma mark - 睡眠结果特殊处理
- (CustomSleepData *)processSleepData:(GDSleepDay *)sleepData
{
    if (!sleepData || !sleepData.getUpPoint) {
        return nil;
    }
    
    // 用户设置睡眠时间 22:00 ~ 07:00
    int expectSleepHour = 22;
    int expectSleepMinute = 0;
    
    int expectGetupHour = 9;
    int expectGetupMinute = 0;
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    NSDate *sleepDate = [NSDate dateWithTimeIntervalSince1970:sleepData.gotoSleepPoint];
    NSDate *getupDate = [NSDate dateWithTimeIntervalSince1970:sleepData.getUpPoint];
    // 用户设置起床时间
    NSDate *expectGetupDate = [calendar dateBySettingHour:expectGetupHour
                                                   minute:expectGetupMinute
                                                   second:0
                                                   ofDate:getupDate
                                                  options:0];
    // 用户设置入睡时间
    NSDate *expectSleepDate = [calendar dateBySettingHour:expectSleepHour
                                                   minute:expectSleepMinute
                                                   second:0
                                                   ofDate:[getupDate dateByAddingTimeInterval:-24 * 60 * 60]
                                                  options:0];
    
    CustomSleepData *customSleepData = [[CustomSleepData alloc] init];
    customSleepData.gotoSleepPoint = sleepData.gotoSleepPoint;
    customSleepData.getUpPoint = sleepData.getUpPoint;
    customSleepData.lightSleepTime = sleepData.lightSleepTime;
    customSleepData.deepSleepTime = sleepData.deepSleepTime;
    customSleepData.wakeupTime = sleepData.wakeupTime;
    customSleepData.detailArray = [sleepData.detailArray mutableCopy];
    
    if (expectSleepDate.timeIntervalSince1970 > sleepDate.timeIntervalSince1970) {
        // 设置的入睡时间晚于计算的入睡时间
        for (NSInteger i = 0; i < customSleepData.detailArray.count; i++) {
            if (i == 0) {
                customSleepData.detailArray[i].time = expectSleepDate.timeIntervalSince1970;
            }
            else {
                if (customSleepData.detailArray[i].time <= expectSleepDate.timeIntervalSince1970) {
                    [customSleepData.detailArray removeObjectAtIndex:i];
                    i --;
                }
                else {
                    break;
                }
            }
        }
    }
    else {
        customSleepData.gotoSleepPoint = expectSleepDate.timeIntervalSince1970;
        customSleepData.detailArray[0].state = GDSleepStateLightSleep;
        
        GDSleepDetail *detail = [[GDSleepDetail alloc] init];
        detail.time = customSleepData.gotoSleepPoint;
        detail.state = GDSleepStateGotoSleep;
        [customSleepData.detailArray insertObject:detail atIndex:0];
    }
    
    if (expectGetupDate.timeIntervalSince1970 < getupDate.timeIntervalSince1970) {
        // 设置的起床时间早于计算的起床时间
        for (NSInteger i = customSleepData.detailArray.count - 1; i >= 0; i--) {
            if (i == customSleepData.detailArray.count - 1) {
                customSleepData.detailArray[i].time = expectGetupDate.timeIntervalSince1970;
            }
            else {
                if (customSleepData.detailArray[i].time >= expectGetupDate.timeIntervalSince1970) {
                    [customSleepData.detailArray removeObjectAtIndex:i];
                    i ++;
                }
                else {
                    break;
                }
            }
        }
    }
    else {
        customSleepData.getUpPoint = expectGetupDate.timeIntervalSince1970;
        [customSleepData.detailArray lastObject].state = GDSleepStateLightSleep;
        
        GDSleepDetail *detail = [[GDSleepDetail alloc] init];
        detail.time = customSleepData.getUpPoint;
        detail.state = GDSleepStateGetUp;
        [customSleepData.detailArray addObject:detail];
    }
    
    // 重新计算各个睡眠状态的时间
    NSTimeInterval lightSleepTime = 0, deepSleepTime = 0, wakeupTime = 0;
    for (NSInteger i = 1; i < customSleepData.detailArray.count; i++) {
        GDSleepDetail *prevDetail = customSleepData.detailArray[i - 1];
        GDSleepDetail *detail = customSleepData.detailArray[i];
        NSTimeInterval interval = detail.time - prevDetail.time;
        GDSleepState state = i == customSleepData.detailArray.count - 1 ? prevDetail.state : detail.state;
        switch (state) {
                
            case GDSleepStateLightSleep:
                lightSleepTime += interval;
                break;
                
            case GDSleepStateDeepSleep:
                deepSleepTime += interval;
                break;
                
            case GDSleepStateWakeup:
                wakeupTime += interval;
                break;
                
            default:
                break;
        }
    }
    
    customSleepData.lightSleepTime = lightSleepTime;
    customSleepData.deepSleepTime = deepSleepTime;
    customSleepData.wakeupTime = wakeupTime;
    
    return customSleepData;
}

- (void)logSleepData:(GDSleepDay *)sleepData
{
    NSMutableString *str = [@"\n" mutableCopy];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    [str appendString:[NSString stringWithFormat:@"入睡：%@\n起床：%@\n浅睡：%d分钟\n深睡：%d分钟\n起夜：%d分钟",
                       [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:sleepData.gotoSleepPoint]],
                       [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:sleepData.getUpPoint]],
                       (int)(sleepData.lightSleepTime / 60),
                       (int)(sleepData.deepSleepTime / 60),
                       (int)(sleepData.wakeupTime / 60)]];
    [str appendString:@"\n"];
    for (GDSleepDetail *detail in sleepData.detailArray) {
        [str appendFormat:@"\n%@\t\t%@", [formatter stringFromDate:[NSDate dateWithTimeIntervalSince1970:detail.time]],
         @[@"未知", @"入睡", @"浅度睡眠", @"深度睡眠", @"起夜", @"起床"][detail.state]];
    }
    NSLog(@"%@", str);
}

#pragma mark - GDBandManagerAPDUDelegate
- (void)didSendApduResult:(BOOL)result responseData:(NSData *)responseData
{
    NSLog(@"send result:%d response %@", result, responseData);
}

- (void)apduTest1
{
    SC_Header header;
    header.CLA = 0x00;
    header.INS = 0xa4;
    header.P1 = 0x00;
    header.P2 = 0x00;
    
    SC_Body body;
    body.LC = 0x02;
    body.LE = 0x00;
    
    Byte bytes[] = {0x10, 0x01};
    memcpy(body.Data, bytes, 2);
    
    SC_ADPU_Commands commands;
    commands.Header = header;
    commands.Body = body;
    
    SC_ADPU_Response response;
    [_bandManager APDUSendReceive:&commands response:&response timeout:3000];
    NSLog(@"APDU response %02X %02X, %d", response.SW1, response.SW2, response.Data_Length);
}

- (void)apduTest2
{
    SC_Header header;
    header.CLA = 0x80;
    header.INS = 0x5c;
    header.P1 = 0x00;
    header.P2 = 0x02;
    
    SC_Body body;
    body.LC = 0x00;
    body.LE = 0x04;
    
    SC_ADPU_Commands commands;
    commands.Header = header;
    commands.Body = body;
    
    SC_ADPU_Response response;
    [_bandManager APDUSendReceive:&commands response:&response timeout:3000];
    NSLog(@"APDU response %02X %02X, %d", response.SW1, response.SW2, response.Data_Length);
}

- (void)showStateText:(NSString *)text
{
    dispatch_async(dispatch_get_main_queue(), ^{
        _stateLabel.text = text;
    });
}

- (void)alertWithTitle:(NSString *)title message:(NSString *)message
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:nil];
    [alertController addAction:cancelAction];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (NSString *)stringWithANCSStatus:(GDBandANCSStatus)status
{
    switch (status) {
        case GDBandANCSStatusOFF:
            return @"全部关闭";
            
        case GDBandANCSStatusAllOn:
            return @"全部开启";
            
        case GDBandANCSStatusCallON:
            return @"来电提醒开启 消息提醒关闭";
            
        case GDBandANCSStatusMessageON:
            return @"来电提醒关闭 消息提醒开启";
            
        default:
            return nil;
    }
}

#pragma mark - GDBandManagerDelegate
- (NSString *)didSendValidateCode
{
    return @"123456";
}

- (void)didFailToConnectDevice
{
    [self showStateText:@"连接失败"];
}

- (void)didConnectDevice
{
    [self showStateText:@"已连接"];
}

- (void)didDisconnectDevice
{
    [self showStateText:@"已断开"];
}

#pragma mark - GDBandDFUDelegate
- (void)bandDFUDidStart
{
    NSLog(@"=== 开始升级 ===");
}

- (void)bandDFUDidUpdateState:(GDBandDFUState)state info:(NSDictionary *)info
{
    NSArray *stateNames = @[@"空闲", @"准备中", @"等待中", @"传输中"];
    if (state == GDBandDFUStateTransfering) {
        NSLog(@"=== 传输中 %d ===", [info[GDDFUInfoPercentageName] intValue]);
        [self showDFUAlertText:[NSString stringWithFormat:@"传输中 %d%%", [info[GDDFUInfoPercentageName] intValue]]];
    }
    else {
        NSLog(@"=== %@ ===", stateNames[state]);
        [self showDFUAlertText:stateNames[state]];
    }
}

- (void)bandDFUDidComplete
{
    NSLog(@"=== 升级完成 ===");
    [self showDFUAlertText:@"升级成功！"];
    [self showDFUAlertCancel];
}

- (void)bandDFUDidCancelWithError:(NSInteger)errorCode
{
    NSLog(@"=== bandDFUDidCancelWithError %ld ===", errorCode);
    [self showDFUAlertText:[NSString stringWithFormat:@"升级失败！错误码：%ld", errorCode]];
    [self showDFUAlertCancel];
}

- (void)showDFUAlertText:(NSString *)text
{
    if (_dfuAlertController) {
        [_dfuAlertController setMessage:text];
    }
}

- (void)showDFUAlertCancel
{
    [_dfuAlertController addAction:[UIAlertAction actionWithTitle:@"确定"
                                                            style:UIAlertActionStyleCancel
                                                          handler:^(UIAlertAction * _Nonnull action) {
                                                              [_dfuAlertController dismissViewControllerAnimated:YES completion:nil];
                                                              _dfuAlertController = nil;
                                                          }]];
}
@end
