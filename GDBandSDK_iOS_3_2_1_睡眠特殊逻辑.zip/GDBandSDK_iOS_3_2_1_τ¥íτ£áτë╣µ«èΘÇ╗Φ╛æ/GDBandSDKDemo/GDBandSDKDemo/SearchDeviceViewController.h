//
//  SearchDeviceViewController.h
//  GDBandSDKDemo
//
//  Created by LiZengshun on 15/11/6.
//  Copyright © 2015年 gieseckedevrient. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GDBandSDK.h"

@interface SearchDeviceViewController : UITableViewController

@end
