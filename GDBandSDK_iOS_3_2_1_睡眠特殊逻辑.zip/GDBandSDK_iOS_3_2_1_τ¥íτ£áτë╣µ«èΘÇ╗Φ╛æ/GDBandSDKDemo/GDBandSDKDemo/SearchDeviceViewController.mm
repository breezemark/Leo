//
//  SearchDeviceViewController.m
//  GDBandSDKDemo
//
//  Created by LiZengshun on 15/11/6.
//  Copyright © 2015年 gieseckedevrient. All rights reserved.
//

#import "SearchDeviceViewController.h"

@interface SearchDeviceViewController ()<GDBandManagerDelegate>
{
    NSMutableArray *_devices;
    NSMutableDictionary *_rssiDic;
    GDBandManager *_bandManager;
}
@property (nonatomic, strong) CBPeripheral *selectedDevice;
@end

@implementation SearchDeviceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _devices = [[NSMutableArray alloc] init];
    _rssiDic = [[NSMutableDictionary alloc] init];
    // SDK初始化
    [GDBandManager initializeWithAppID:@"20028" appKey:@"3f64f8af4b522d4ddff15b1ff44dbf8f" showSystemAlert:YES];
    _bandManager = [GDBandManager sharedManager];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    _bandManager.delegate = self;
    [_bandManager startDiscoverDevice];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _devices.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DeviceCell"];
    CBPeripheral *peripheral = [_devices objectAtIndex:indexPath.row];
    cell.textLabel.text = peripheral.name;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%d", [[_rssiDic objectForKey:peripheral] intValue]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    _selectedDevice = [_devices objectAtIndex:indexPath.row];
    [self performSegueWithIdentifier:@"DeviceView" sender:self];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    UIViewController *dest = segue.destinationViewController;
    if ([dest respondsToSelector:@selector(setSelectedDevice:)]) {
        [dest performSelector:@selector(setSelectedDevice:) withObject:_selectedDevice];
    }
}

- (void)didDiscoverDevice:(CBPeripheral *)peripheral RSSI:(NSNumber *)RSSI
{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (![_devices containsObject:peripheral]) {
            [_devices addObject:peripheral];
        }
        [_rssiDic setObject:RSSI forKey:peripheral];
        [self.tableView reloadData];
    });
}
@end
