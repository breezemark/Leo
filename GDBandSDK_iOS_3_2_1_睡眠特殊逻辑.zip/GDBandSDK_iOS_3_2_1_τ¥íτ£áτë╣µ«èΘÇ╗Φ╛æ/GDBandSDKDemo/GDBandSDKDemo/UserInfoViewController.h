//
//  UserInfoViewController.h
//  GDBandSDK
//
//  Created by darren on 15/11/4.
//  Copyright © 2015年 gieseckedevrient. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserInfoViewController : UITableViewController

@property (weak, nonatomic) IBOutlet UILabel *heightLabel;
@property (weak, nonatomic) IBOutlet UILabel *weightLabel;
@property (weak, nonatomic) IBOutlet UILabel *ageLabel;
@property (weak, nonatomic) IBOutlet UILabel *sexLabel;
@property (weak, nonatomic) IBOutlet UILabel *walkingLengthLabel;
@property (weak, nonatomic) IBOutlet UILabel *runningLengthLabel;
@end
