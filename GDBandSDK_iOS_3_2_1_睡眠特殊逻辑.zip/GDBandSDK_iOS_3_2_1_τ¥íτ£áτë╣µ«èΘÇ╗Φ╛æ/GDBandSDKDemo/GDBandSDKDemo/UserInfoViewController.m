//
//  UserInfoViewController.m
//  GDBandSDK
//
//  Created by darren on 15/11/4.
//  Copyright © 2015年 gieseckedevrient. All rights reserved.
//

#import "UserInfoViewController.h"
#import "GDBandSDK.h"

@interface UserInfoViewController ()<UIAlertViewDelegate>
{
    GDUserInfo *_userInfo;
}
@end

@implementation UserInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.section) {
        case 0:
        {
            if (!_userInfo) {
                [self showAlertText:@"请先读取设置"];
                break;
            }
            switch (indexPath.row) {
                case 0:
                {
                    [self showInputAlertWithText:@"请输入身高：（单位:cm 例:170）" tag:101];
                }
                    break;
                    
                case 1:
                {
                    [self showInputAlertWithText:@"请输入体重：（单位:kg 例:60）" tag:102];
                }
                    break;
                    
                case 2:
                {
                    [self showInputAlertWithText:@"请输入年龄：（例:25）" tag:103];
                }
                    break;
                    
                case 3:
                {
                    [self showInputAlertWithText:@"请输入性别：（输入1为男，2为女 例:1）" tag:104];
                }
                    break;
                    
                case 4:
                {
                    [self showInputAlertWithText:@"请输入走路步长：（单位:cm 例:60）" tag:105];
                }
                    break;
                    
                case 5:
                {
                    [self showInputAlertWithText:@"请输入跑步步长：（单位:kg 例:90）" tag:106];
                }
                    break;
                    
                default:
                    break;
            }
        }
            break;
            
        case 1:
        {
            switch (indexPath.row) {
                case 0:
                {
                    BOOL success = [[GDBandManager sharedManager] getUserInfo:^(BOOL success, GDUserInfo *userInfo) {
                        if (success) {
                            _userInfo = userInfo;
                            [self refreshDisplay];
                        }
                        else {
                            [self showAlertText:@"通讯失败"];
                        }
                    }];
                    if (!success) {
                        [self showAlertText:@"手环未连接"];
                    }
                }
                    break;
                    
                case 1:
                {
                    if (!_userInfo) {
                        [self showAlertText:@"请先读取设置"];
                        break;
                    }
                    BOOL success = [[GDBandManager sharedManager] updateUserInfo:_userInfo completion:^(BOOL success) {
                        [self showAlertText:success ? @"设置成功" : @"设置失败"];
                    }];
                    if (!success) {
                        [self showAlertText:@"手环未连接"];
                    }
                }
                    break;
                    
                default:
                    break;
            }
        }
            break;
            
        default:
            break;
    }
}

- (void)showInputAlertWithText:(NSString *)text tag:(NSInteger)tag
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:text delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [alertView setAlertViewStyle:UIAlertViewStylePlainTextInput];
    [[alertView textFieldAtIndex:0] setKeyboardType:UIKeyboardTypeNumberPad];
    alertView.tag = tag;
    [alertView show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1) {
        UITextField *tf = [alertView textFieldAtIndex:0];
        switch (alertView.tag) {
            case 101:
            {
                _userInfo.height = tf.text.intValue;
                [self refreshDisplay];
            }
                break;
                
            case 102:
            {
                _userInfo.weight = tf.text.intValue;
                [self refreshDisplay];
            }
                break;
                
            case 103:
            {
                _userInfo.age = tf.text.intValue;
                [self refreshDisplay];
            }
                break;
                
            case 104:
            {
                _userInfo.sex = tf.text.intValue;
                [self refreshDisplay];
            }
                break;
                
            case 105:
            {
                _userInfo.walkingLength = tf.text.intValue;
                [self refreshDisplay];
            }
                break;
                
            case 106:
            {
                _userInfo.runningLength = tf.text.intValue;
                [self refreshDisplay];
            }
                break;
                
            default:
                break;
        }
    }
}

- (void)refreshDisplay
{
    _heightLabel.text = [NSString stringWithFormat:@"%d cm", _userInfo.height];
    _weightLabel.text = [NSString stringWithFormat:@"%d kg", _userInfo.weight];
    _ageLabel.text = [NSString stringWithFormat:@"%d", _userInfo.age];
    _sexLabel.text = _userInfo.sex == 1 ? @"男" : _userInfo.sex == 2 ? @"女" : @"未知";
    _walkingLengthLabel.text = [NSString stringWithFormat:@"%d cm", _userInfo.walkingLength];
    _runningLengthLabel.text = [NSString stringWithFormat:@"%d cm", _userInfo.runningLength];
}

- (void)showAlertText:(NSString *)text
{
    [[[UIAlertView alloc] initWithTitle:@"提示" message:text delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil] show];
}

@end
